package com.example.Quiz2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Quiz2Application {

	public static void main(String[] args) {
		SpringApplication.run(Quiz2Application.class, args);
	}

}
